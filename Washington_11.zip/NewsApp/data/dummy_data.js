import News from "../models/news";

export const NEWS = [
  new News(
    1,
    "US News",
    "Congress Passes Infrastructure Bill",
    "October 25, 2025",
    "Sarah Johnson",
    "CNN",
    "The U.S. Congress has passed a major infrastructure bill that will allocate billions of dollars toward repairing and modernizing the nation's roads, bridges, and broadband networks. The legislation received bipartisan support and is expected to create thousands of jobs nationwide.",
    "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=600&fit=crop"
  ),
  new News(
    2,
    "World News",
    "Climate Summit Reaches Historic Agreement",
    "October 26, 2025",
    "Michael Chen",
    "BBC",
    "World leaders at the Global Climate Summit have reached a historic agreement to reduce carbon emissions by 50% by 2030. The agreement includes commitments from over 190 countries and represents the most ambitious climate action plan to date.",
    "https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?w=800&h=600&fit=crop"
  ),
  new News(
    3,
    "Tech News",
    "AI Breakthrough in Medical Diagnosis",
    "October 27, 2025",
    "Dr. Emily Rodriguez",
    "TechCrunch",
    "Researchers have developed an AI system that can diagnose certain medical conditions with 95% accuracy, potentially revolutionizing healthcare. The system uses advanced machine learning algorithms to analyze medical images and patient data.",
    "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=600&fit=crop"
  ),
  new News(
    4,
    "US News",
    "Federal Reserve Announces Interest Rate Decision",
    "October 28, 2025",
    "David Thompson",
    "Fox News",
    "The Federal Reserve has announced its decision to maintain current interest rates amid ongoing economic uncertainty. Fed Chair emphasized the need for continued monitoring of inflation and employment data before making future rate adjustments.",
    "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=600&fit=crop"
  ),
  new News(
    5,
    "World News",
    "European Union Announces New Trade Agreements",
    "October 29, 2025",
    "Anna Mueller",
    "Reuters",
    "The European Union has signed new trade agreements with several Asian countries, aimed at strengthening economic ties and reducing trade barriers. The agreements are expected to boost economic growth and create new opportunities for businesses on both sides.",
    "https://images.unsplash.com/photo-1519452575417-564c1401ecc0?w=800&h=600&fit=crop"
  ),
  new News(
    6,
    "Tech News",
    "Quantum Computing Milestone Achieved",
    "October 24, 2025",
    "Prof. James Wilson",
    "Wired",
    "Scientists have achieved a major breakthrough in quantum computing, successfully demonstrating quantum supremacy in solving complex mathematical problems. This advancement could lead to revolutionary changes in cryptography, drug discovery, and artificial intelligence.",
    "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&h=600&fit=crop"
  ),
  new News(
    7,
    "US News",
    "Supreme Court Hears Landmark Privacy Case",
    "October 23, 2025",
    "Jessica Park",
    "NPR",
    "The Supreme Court is hearing arguments in a landmark case that could reshape digital privacy rights in America. The case involves government surveillance powers and the privacy expectations of citizens in the digital age.",
    "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&h=600&fit=crop"
  ),
  new News(
    8,
    "World News",
    "International Space Station Mission Launch",
    "October 22, 2025",
    "Captain Maria Santos",
    "AP News",
    "A new international mission to the International Space Station has launched successfully, carrying experiments that could lead to breakthroughs in medicine and materials science. The crew includes astronauts from five different countries.",
    "https://images.unsplash.com/photo-1446776877081-d282a0f896e2?w=800&h=600&fit=crop"
  ),
  new News(
    9,
    "Tech News",
    "Breakthrough in Renewable Energy Storage",
    "October 21, 2025",
    "Dr. Kevin Liu",
    "MIT Technology Review",
    "Researchers have developed a new battery technology that could store renewable energy for months at a time. This breakthrough could solve one of the biggest challenges facing renewable energy adoption and grid stability.",
    "https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=800&h=600&fit=crop"
  ),
  new News(
    10,
    "US News",
    "Major Education Reform Bill Proposed",
    "October 20, 2025",
    "Rebecca Martinez",
    "ABC News",
    "Lawmakers have proposed a comprehensive education reform bill that would increase funding for public schools and expand access to higher education. The bill includes provisions for student loan forgiveness and increased teacher salaries.",
    "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=800&h=600&fit=crop"
  ),
  new News(
    11,
    "World News",
    "Global Food Security Initiative Launched",
    "October 19, 2025",
    "Ahmed Hassan",
    "Al Jazeera",
    "The United Nations has launched a global initiative to address food security challenges worldwide. The program aims to reduce hunger and malnutrition through sustainable agriculture practices and improved food distribution systems.",
    "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800&h=600&fit=crop"
  ),
  new News(
    12,
    "Tech News",
    "Revolutionary Gene Therapy Shows Promise",
    "October 18, 2025",
    "Dr. Lisa Chang",
    "Nature",
    "Clinical trials for a new gene therapy treatment have shown remarkable success in treating previously incurable genetic diseases. The therapy uses CRISPR technology to correct genetic defects at the cellular level.",
    "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&h=600&fit=crop"
  ),
  new News(
    13,
    "US News",
    "National Cybersecurity Strategy Updated",
    "October 17, 2025",
    "Robert Kim",
    "Washington Post",
    "The government has unveiled an updated national cybersecurity strategy to protect against evolving digital threats. The strategy includes new public-private partnerships and increased funding for cybersecurity research and development.",
    "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&h=600&fit=crop"
  ),
  new News(
    14,
    "World News",
    "Antarctica Research Reveals Climate Data",
    "October 16, 2025",
    "Dr. Sophie Anderson",
    "National Geographic",
    "New research from Antarctica has revealed important data about historical climate patterns that could help scientists better predict future climate change. The study analyzed ice cores dating back thousands of years.",
    "https://images.unsplash.com/photo-1551522435-a13afa10f103?w=800&h=600&fit=crop"
  ),
  new News(
    15,
    "Tech News",
    "New Smartphone Technology Unveiled",
    "October 15, 2025",
    "Mark Johnson",
    "The Verge",
    "Tech giant announces breakthrough smartphone technology featuring holographic displays and week-long battery life. The new devices incorporate advanced materials and energy-efficient processors to achieve unprecedented performance.",
    "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&h=600&fit=crop"
  ),
  new News(
    16,
    "US News",
    "Healthcare Reform Debate Intensifies",
    "October 14, 2025",
    "Dr. Patricia Williams",
    "USA Today",
    "Congressional debates over healthcare reform have intensified as lawmakers work to address rising healthcare costs and improve access to medical services. The proposed reforms include prescription drug price controls and expanded Medicare coverage.",
    "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=800&h=600&fit=crop"
  ),
  new News(
    17,
    "World News",
    "Global Economic Recovery Shows Progress",
    "October 13, 2025",
    "Thomas Brown",
    "Financial Times",
    "International economic indicators show continued progress in global recovery efforts. GDP growth has exceeded expectations in major economies, though challenges remain in developing nations affected by climate change and political instability.",
    "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&h=600&fit=crop"
  ),
  new News(
    18,
    "Tech News",
    "Autonomous Vehicle Testing Expands",
    "October 12, 2025",
    "Jennifer Lee",
    "Ars Technica",
    "Major automotive companies have expanded autonomous vehicle testing to additional cities nationwide. The expanded testing includes various weather conditions and traffic scenarios to improve the safety and reliability of self-driving cars.",
    "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=800&h=600&fit=crop"
  ),
  new News(
    19,
    "US News",
    "Immigration Policy Changes Announced",
    "October 11, 2025",
    "Carlos Mendez",
    "PBS NewsHour",
    "The administration has announced significant changes to immigration policy aimed at streamlining the legal immigration process and addressing humanitarian concerns. The changes include expanded refugee programs and improved visa processing systems.",
    "https://images.unsplash.com/photo-1560472355-536de3962603?w=800&h=600&fit=crop"
  ),
  new News(
    20,
    "World News",
    "Ocean Conservation Initiative Gains Support",
    "October 10, 2025",
    "Dr. Marina Costa",
    "Ocean Magazine",
    "An international ocean conservation initiative has gained support from over 100 countries committed to protecting marine ecosystems. The initiative includes measures to reduce plastic pollution and establish new marine protected areas.",
    "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop"
  ),
];
