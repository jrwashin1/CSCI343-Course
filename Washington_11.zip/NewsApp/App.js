import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import { useEffect } from "react";
import * as Font from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

// Icon imports for navigation
import {
  Entypo,
  MaterialIcons,
  MaterialCommunityIcons,
} from "@expo/vector-icons";
import colors from "./constants/colors.js";

import USNewsScreen from "./screens/USNewsScreen";
import BookmarkedNewsScreen from "./screens/BookmarkedNewsScreen";
import WorldNewsScreen from "./screens/WorldNewsScreen";
import TechNewsScreen from "./screens/TechNewsScreen";
import NewsDetailScreen from "./screens/NewsDetailScreen";
import FavoritesContextProvider from "./store/context/favorites-context";

// Keep the splash screen visible during fonts loading process
SplashScreen.preventAutoHideAsync();

// The three different navigators we'll use
const Stack = createNativeStackNavigator(); // For main navigation (goes between major sections)
const Drawer = createDrawerNavigator(); // For side menu (hamburger menu)
const Tabs = createBottomTabNavigator(); // For bottom tabs (US/World/Tech news)

// Drawer navigator: Creates the side menu with 2 options
function DrawerNavigator() {
  return (
    <Drawer.Navigator
      initialRouteName="News" // Start with News tab when app opens
      screenOptions={{
        // Style the header/drawer appearance
        headerStyle: { backgroundColor: colors.primary500 },
        headerTintColor: "White",
        headerTitleStyle: {
          fontFamily: "nolluqa",
          fontSize: 40,
          color: colors.accent800,
        },
        sceneContainerStyle: { backgroundColor: colors.primary300 },
        drawerContentStyle: { backgroundColor: colors.primary500 },
        drawerInactiveTintColor: colors.primary300,
        drawerActiveTintColor: colors.accent500,
        drawerActiveBackgroundColor: colors.primary800,
      }}
    >
      {/* First drawer option - News Categories (leads to bottom tabs) */}
      <Drawer.Screen
        name="News"
        component={TabsNavigator}
        options={{
          title: "All News",
          drawerLabel: "News Categories",
          drawerIcon: ({ color, size }) => (
            <Entypo name="news" color={color} size={size} />
          ),
        }}
      />
      {/* Second drawer option - Bookmarked News */}
      <Drawer.Screen
        name="BookmarkedNews"
        component={BookmarkedNewsScreen}
        options={{
          title: "Bookmarked News",
          drawerLabel: "Bookmarked News",
          drawerIcon: ({ color, size }) => (
            <Entypo name="bookmark" color={color} size={size} />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

function TabsNavigator() {
  return (
    <Tabs.Navigator
      screenOptions={{
        // Style the bottom tab bar
        tabBarShowLabel: true,
        tabBarActiveBackgroundColor: colors.primary800,
        tabBarActiveTintColor: colors.accent500,
        tabBarInactiveBackgroundColor: colors.primary500,
        tabBarInactiveTintColor: colors.primary300,
        tabBarLabelStyle: { fontFamily: "playfairBold", fontSize: 12 },
        tabBarStyle: { backgroundColor: colors.primary500 },
      }}
    >
      {/* Tab 1: US News */}
      <Tabs.Screen
        name="USNews"
        component={USNewsScreen}
        options={{
          headerShown: false, // Hide header because drawer handles it
          tabBarIcon: ({ color, size }) => (
            <Entypo name="flag" color={color} size={size} />
          ),
          tabBarLabel: "US News",
        }}
      />
      {/* Tab 2: World News */}
      <Tabs.Screen
        name="WorldNews"
        component={WorldNewsScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ color, size }) => (
            <Entypo name="globe" color={color} size={size} />
          ),
          tabBarLabel: "World News",
        }}
      />
      {/* Tab 3: Tech News */}
      <Tabs.Screen
        name="TechNews"
        component={TechNewsScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="computer" color={color} size={size} />
          ),
          tabBarLabel: "Tech News",
        }}
      />
    </Tabs.Navigator>
  );
}

export default function App() {
  // Load custom fonts and track loading state
  const [loaded] = Font.useFonts({
    playfair: require("./assets/fonts/Playfair.ttf"),
    playfairBold: require("./assets/fonts/PlayfairBold.ttf"),
    playfairItalic: require("./assets/fonts/PlayfairBoldItalic.ttf"),
    nolluqa: require("./assets/fonts/NolluqaRegular.otf"),
  });

  // Hide splash screen once fonts are loaded
  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  // Don't render anything until fonts are loaded
  if (!loaded) {
    return null;
  }

  return (
    <>
      <StatusBar style="light" />
      <FavoritesContextProvider>
        <NavigationContainer>
          <Stack.Navigator
            initialRouteName="DrawerScreen" // Start with drawer menu
            screenOptions={{
              headerTintColor: colors.primary300,
              headerStyle: { backgroundColor: colors.primary500 },
              contentStyle: { backgroundColor: "black" },
            }}
          >
            {/* Main screen with drawer navigation */}
            <Stack.Screen
              name="DrawerScreen"
              component={DrawerNavigator}
              options={{ headerShown: false }}
            />
            {/* Detail screen for individual news articles */}
            <Stack.Screen
              name="NewsDetail"
              component={NewsDetailScreen}
              options={{ headerShown: true }}
            />
          </Stack.Navigator>
        </NavigationContainer>
      </FavoritesContextProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
