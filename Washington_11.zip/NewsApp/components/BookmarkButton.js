import { Ionicons } from "@expo/vector-icons";
import { Pressable } from "react-native";
import colors from "../constants/colors.js";

export default function BookmarkButton(props) {
  if (props.isFavorite) {
    return (
      <Pressable onPress={props.onPress}>
        <Ionicons name="bookmark" size={30} color={colors.accent500} />
      </Pressable>
    );
  } else {
    return (
      <Pressable onPress={props.onPress}>
        <Ionicons name="bookmark-outline" size={30} color={colors.accent500} />
      </Pressable>
    );
  }
}
