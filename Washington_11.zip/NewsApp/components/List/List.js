import ListingItem from "./ListingItem";
import { View, FlatList, StyleSheet } from "react-native";

export default function List(props) {
  function renderNewsItem(itemData) {
    // Extract all the news data to pass to each ListingItem
    const newsItemProps = {
      id: itemData.item.id,
      headline: itemData.item.headline,
      date: itemData.item.date,
      author: itemData.item.author,
      agency: itemData.item.agency,
      imageUrl: itemData.item.imageUrl,
      description: itemData.item.description,
      listIndex: itemData.index,
    };
    return <ListingItem {...newsItemProps} />;
  }

  return (
    <View style={styles.container}>
      {/* FlatList efficiently renders long lists of data */}
      <FlatList
        data={props.items} // The array of news items to display
        keyExtractor={(item) => item.id} // Use ID as unique key for each item
        renderItem={renderNewsItem} // Function to render each item
        showsVerticalScrollIndicator={false} // Hide the scroll bar
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "black",
  },
});
